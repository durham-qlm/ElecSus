# Copyright 2014 M. A. Zentile, J. Keaveney, L. Weller, D. Whiting,
# C. S. Adams and I. G. Hughes.

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

#     http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Atom/transition related constants

Hyperfine constants are in units of MHz
nuclear spin g-factors are those corresponding to the Bohr magneton.

Called by EigenSystem.py

"""

from numpy import pi, sqrt
from FundamentalConstants import *

class Rb85:
    """Constants relating to the rubidium-85 atom"""
    I  = 2.5         #Nuclear spin
    As = 1011.910813 #Ground state hyperfine constant in units of MHz
    gI = -0.00029364 #nuclear spin g-factor
    mass = 84.911789732*amu

class Rb87:
    """Constants relating to the rubidium-87 atom"""
    I  = 1.5 
    As = 3417.34130545215 #3.417341305452145
    gI = -0.0009951414 
    mass = 86.909180520*amu

class Cs:
    """Constants relating to the caesium-133 atom"""
    I  = 3.5         #Nuclear spin
    As = 2298.1579425 #Ground state hyperfine constant in units of MHz
    gI = -0.00039885395 #nuclear spin g-factor
    mass = 132.905451933*amu

class K39:
    """Constants relating to the potassium-39 atom"""
    I  = 1.5
    As = 230.8598601
    gI = -0.00014193489
    mass = 38.96370668*amu

class K40:
    """Constants relating to the potassium-40 atom"""
    I  = 4.0
    As = -285.7308
    gI = 0.000176490
    mass = 39.96399848*amu

class K41:
    """Constants relating to the potassium-41 atom"""
    I  = 1.5
    As = 127.0069352
    gI = -0.00007790600
    mass = 40.96182576*amu

class Na:
    """Constants relating to the sodium-23 atom"""
    I  = 1.5
    As = 885.8130644
    gI = -0.0008046108
    mass = 22.9897692807*amu

# Element-Transition constants

class RbD1Transition:
    """Constants relating to the rubidium D1 transition"""
    wavelength=794.978969380e-9 #The weighted linecentre of the rubidium D1 line in m
    wavevectorMagnitude=2.0*pi/wavelength #Magnitude of the wavevector
    NatGamma=5.746 #Rubidium D1 natural linewidth in MHz
    dipoleStrength=3.0*sqrt(e0*hbar*(2.0*NatGamma*(10.0**6))*(wavelength**3)/(8.0*pi))
    v0=377107407.299e6 #The weighted linecentre of the rubidium D1 line in Hz

class RbD2Transition:
    """Constants relating to the rubidium D2 transition"""
    wavelength=780.24132411e-9
    wavevectorMagnitude=2.0*pi/wavelength
    NatGamma=6.065
    dipoleStrength=3.0*sqrt(e0*hbar*(2.0*NatGamma*(10.0**6))*(wavelength**3)/(8.0*pi))
    v0=384230428.12e6

class CsD1Transition:
    """Constants relating to the caesium D1 transition"""
    wavelength=894.59295986e-9 #The weighted linecentre of the caesium D1 line in m
    wavevectorMagnitude=2.0*pi/wavelength #Magnitude of the wavevector
    NatGamma=4.584 #Caesium D1 natural linewidth in MHz
    dipoleStrength=3.0*sqrt(e0*hbar*(2.0*NatGamma*(10.0**6))*(wavelength**3)/(8.0*pi))
    v0=335116048.807e6 #The weighted linecentre of the caesium D1 line in Hz

class CsD2Transition:
    """Constants relating to the caesium D2 transition"""
    wavelength=852.34727582e-9
    wavevectorMagnitude=2.0*pi/wavelength
    NatGamma=5.225
    dipoleStrength=3.0*sqrt(e0*hbar*(2.0*NatGamma*(10.0**6))*(wavelength**3)/(8.0*pi))
    v0=351725718.50e6

class KD1Transition:
    """Constants relating to the potassium D1 transition"""
    wavelength=770.10836827e-9 #The linecentre of Potassium in metres
    wavevectorMagnitude=2.0*pi/wavelength #Magnitude of the wavevector
    NatGamma=5.956 #Potassium D1 natural linewidth in MHz
    dipoleStrength=3.0*sqrt(e0*hbar*(2.0*NatGamma*(10.0**6))*(wavelength**3)/(8.0*pi))
    v0=389286067.199e6 #Potassium linecentre D1 transition in Hz

class KD2Transition:
    """Constants relating to the potassium D2 transition"""
    wavelength=766.70090511e-9 #The linecentre of Potassium in metres
    wavevectorMagnitude=2.0*pi/wavelength #Magnitude of the wavevector
    NatGamma=6.035 #Potassium D1 natural linewidth in MHz
    dipoleStrength=3.0*sqrt(e0*hbar*(2.0*NatGamma*(10.0**6))*(wavelength**3)/(8.0*pi))
    v0=391016178.54e6 #Potassium linecentre D2 transition in Hz

class NaD1Transition:
    """Constants relating to the sodium D1 transition"""
    wavelength=589.7558147e-9 #The weighted linecentre of the sodium D1 line
    wavevectorMagnitude=2.0*pi/wavelength
    NatGamma=9.765
    dipoleStrength=3.0*sqrt(e0*hbar*(2.0*NatGamma*(10.0**6))*(wavelength**3)/(8.0*pi))
    v0=508.3331958e12 #Sodium D1 linecentre in Hz

class NaD2Transition:
    """Constants relating to the sodium D2 transition"""
    wavelength=589.1583264e-9 #The weighted linecentre of the sodium D1 line
    wavevectorMagnitude=2.0*pi/wavelength
    NatGamma=9.7946
    dipoleStrength=3.0*sqrt(e0*hbar*(2.0*NatGamma*(10.0**6))*(wavelength**3)/(8.0*pi))
    v0=508.8487162e12 #Sodium D1 linecentre in Hz

#### Isotope-Transition constants ####

# Note that isotope shifts are defined here as the negative to
# How they appear in the manual.

class Rb85_D1:
    """Constants relating to rubidium-85 and the D1 transition"""
    #Hyperfine constants in units of MHz
    Ap = 120.640
    Bp = 0.0
    IsotopeShift = 21.624 #MHz. Shifts the ground (S) manifold up.

class Rb85_D2:
    """Constants relating to rubidium-85 and the D2 transition"""
    #Hyperfine constants in units of MHz
    Ap = 25.038
    Bp = 26.011
    IsotopeShift = 21.734 #MHz

class Rb87_D1:
    """Constants relating to rubidium-87 and the D1 transition"""
    #Hyperfine constants in units of MHz
    Ap = 406.147
    Bp = 0.0
    IsotopeShift = -56.077 #MHz

class Rb87_D2:
    """Constants relating to rubidium-87 and the D2 transition"""
    #Hyperfine constants in units of MHz
    Ap = 84.7185
    Bp = 12.4965
    IsotopeShift = -56.361 #MHz

class Cs_D1:
    """Constants relating to the caesium-133 atom and the D1 transition"""
    #Hyperfine constants in units of MHz
    Ap = 291.922
    Bp = 0.0
    IsotopeShift = 0.0 #Only one isotope for Caesium

class Cs_D2:
    """Constants relating to the caesium-133 atom and the D2 transition"""
    #Hyperfine constants in units of MHz
    Ap = 50.28827
    Bp = -0.4934
    IsotopeShift = 0.0

class K39_D1:
    """Constants relating to the potassium-39 atom and the D1 transition"""
    #Hyperfine constants in units of MHz
    Ap = 27.775
    Bp = 0.0
    IsotopeShift = 8.483 #MHz. If positive, shifts the ground (S) manifold up.

class K39_D2:
    """Constants relating to the potassium-39 atom and the D2 transition"""
    #Hyperfine constants in units of MHz
    Ap = 6.093
    Bp = 2.786
    IsotopeShift = 8.51

class K40_D1:
    """Constants relating to the potassium-40 atom and the D1 transition"""
    #Hyperfine constants in units of MHz
    Ap = -34.523
    Bp = 0.0
    IsotopeShift = -117.154

class K40_D2:
    """Constants relating to the potassium-40 atom and the D2 transition"""
    #Hyperfine constants in units of MHz
    Ap = -7.585
    Bp = -3.445
    IsotopeShift = -117.51

class K41_D1:
    """Constants relating to the potassium-41 atom and the D1 transition"""
    #Hyperfine constants in units of MHz
    Ap = 15.245
    Bp = 0.0
    IsotopeShift = -227.006

class K41_D2:
    """Constants relating to the potassium-41 atom and the D2 transition"""
    #Hyperfine constants in units of MHz
    Ap = 3.363
    Bp = 3.351
    IsotopeShift = -227.67

class Na_D1:
    """Constants relating to the sodium-23 atom and the D1 transition"""
    #Hyperfine constants in units of MHz
    Ap = 94.44
    Bp = 0
    IsotopeShift = 0.0 #Only one isotope.

class Na_D2:
    """Constants relating to the sodium-23 atom and the D2 transition"""
    #Hyperfine constants in units of MHz
    Ap = 18.534
    Bp = 2.724
    IsotopeShift = 0.0 #Only one isotope.
