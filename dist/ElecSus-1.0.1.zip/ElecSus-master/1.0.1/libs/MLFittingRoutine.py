# Copyright 2014 M. A. Zentile, J. Keaveney, L. Weller, D. Whiting,
# C. S. Adams and I. G. Hughes.

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

#     http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

'''Marquardt-Levenberg fit module'''

from numpy import array
from scipy.optimize import curve_fit

def MLfit(xdata,ydata,initParams,paramBools):
    x = array(xdata)
    y = array(ydata)
    from spectra import spectrum

    functionString = "def ForFit(x,"
    spectrumString = "spec = spectrum(x,initParams[0],initParams[1],"
    initialGuesses = []
    counter = 0
    for boolian in paramBools:
        if boolian and (counter == 0):
            spectrumString = spectrumString + "B,"
            functionString = functionString + "B,"
            initialGuesses.append(initParams[2])
        elif (not boolian) and (counter == 0):
            spectrumString = spectrumString + "initParams[2],"
        if boolian and (counter == 1):
            functionString = functionString + "T,"
            spectrumString = spectrumString + "T,"
            initialGuesses.append(initParams[3])
        elif (not boolian) and (counter == 1):
            spectrumString = spectrumString + "initParams[3],"
        if boolian and (counter == 2):
            functionString = functionString + "LenCell,"
            spectrumString = spectrumString + "LenCell,"
            initialGuesses.append(initParams[4])
        elif (not boolian) and (counter == 2):
            spectrumString = spectrumString + "initParams[4],"
        if boolian and (counter == 3):
            spectrumString = spectrumString + "Rb85fr,"
            functionString = functionString + "Rb85fr,"
            initialGuesses.append(initParams[5])
        elif (not boolian) and (counter == 3):
            spectrumString = spectrumString + "initParams[5],"
        if boolian and (counter == 4):
            functionString = functionString + "DopT,"
            spectrumString = spectrumString + "DopT,"
            initialGuesses.append(initParams[6])
        elif (not boolian) and (counter == 4):
            spectrumString = spectrumString + "initParams[6],"
        if boolian and (counter == 5):
            functionString = functionString + "Theta0,"
            spectrumString = spectrumString + "Theta0,"
            initialGuesses.append(initParams[7])
        elif (not boolian) and (counter == 5):
            spectrumString = spectrumString + "initParams[7],"
        if boolian and (counter == 6):
            functionString = functionString + "Pol,"
            spectrumString = spectrumString + "Pol,"
            initialGuesses.append(initParams[8])
        elif (not boolian) and (counter == 6):
            spectrumString = spectrumString + "initParams[8],"
        if boolian and (counter == 7):
            functionString = functionString + "Sh,"
            spectrumString = spectrumString + "Sh,"
            initialGuesses.append(initParams[9])
        elif (not boolian) and (counter == 7):
            spectrumString = spectrumString + "initParams[9],"
        if boolian and (counter == 8):
            functionString = functionString + "GamBuf,"
            spectrumString = spectrumString + "GamBuf,"
            initialGuesses.append(initParams[10])
        elif (not boolian) and (counter == 8):
            spectrumString = spectrumString + "initParams[10],"
        counter += 1
    functionString = functionString + "):"
    spectrumString = spectrumString + "initParams[11],initParams[12],initParams[13],initParams[14],initParams[15])"
    code = functionString + "\n    " + spectrumString + "\n    " + "return spec"

    exec code in locals()

    Popt, Pcov, infodict, errmsg, ier  = curve_fit(ForFit,x,y,initialGuesses,full_output=True)
    finalSpecCode = "spectr = ForFit(x,"
    for i in range(len(Popt)):
        finalSpecCode = finalSpecCode + "Popt[" + str(i) + "],"
    finalSpecCode = finalSpecCode + ")"

    exec finalSpecCode

    bestFitParams = [initParams[2],initParams[3],initParams[4],initParams[5],
                     initParams[6],initParams[7],initParams[8],initParams[9],
                     initParams[10]]
    i = 0
    j = 0
    for boo in paramBools:
        if boo:
            bestFitParams[j] = Popt[i]
            i+=1
        j+=1

    return bestFitParams, spectr
    