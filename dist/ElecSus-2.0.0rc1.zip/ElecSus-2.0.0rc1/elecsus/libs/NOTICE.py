noticestring = 'ElecSus v2.0.0 (Last updated 2015-09-02)\n\n\
Distributed under the Apache License, Version 2.0.\n\n\
If the use of this program has contributed to a publication please cite: \n\
M. A. Zentile et al., Comp. Phys. Commun. 189, p162-174 (2015)'